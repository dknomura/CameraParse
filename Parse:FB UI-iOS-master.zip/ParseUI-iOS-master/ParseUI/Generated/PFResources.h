// This is an auto-generated file.
#import <Foundation/Foundation.h>
@interface PFResources : NSObject
+ (NSData *)facebook_icon_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)facebook_icon2x_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)facebook_icon3x_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)parse_logo_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)parse_logo2x_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)parse_logo3x_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)twitter_icon_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)twitter_icon2x_png;//modified:2015-10-08 12:36:36 -0700
+ (NSData *)twitter_icon3x_png;//modified:2015-10-08 12:36:36 -0700
@end
