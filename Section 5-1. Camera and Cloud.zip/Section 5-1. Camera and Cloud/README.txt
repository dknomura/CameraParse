ASSIGNMENT:

Part 1: Photo + Cloud app
	The sample was created using an old version of the Amazon SDK. This is a common problem to encounter on the job.
	Refactor (don't re-create, *refactor*) the project so that it uses Parse instead of Amazon Web Services. 
	Make sure to use a DAO like you did with Core Data so that your views are not using any Parse objects.

Part 2: Add a Parse login for accessing your app. 
Part 3: User should also have the option to login through Facebook. 
Part 4: User should not be able to use the app without logging in.
Part 5: Add a like button (similar to facebook/instagram) for each photo that says how many users have liked the photo.
Part 6: Add a comments feature for each image. (similar to facebook/instagram)