static NSString * const ACCESS_KEY_ID = @"AKIAIJ6GWU7YZEOVWIOA";
static NSString * const SECRET_KEY = @"laKkl12XP81y7z5YiyK4M3cqewXAEr6r";
static NSString * const BUCKET = @"turntotech";


@interface Constants:NSObject {
}

+(NSString *)uploadBucket;

@end
