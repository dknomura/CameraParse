//
//  PAPPhotoDetailsTableViewControllerViewController.h
//  AnyPic
//
//  Created by Mattieu Gamache-Asselin on 5/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Parse/Parse.h>

@interface PAPPhotoDetailsTableViewControllerViewController : PFQueryTableViewController

@end
