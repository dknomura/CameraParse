//
//  PAPSettingsButtonItem.h
//  Anypic
//
//  Created by Héctor Ramos on 5/18/12.
//  Copyright (c) 2013 Parse. All rights reserved.
//

@interface PAPSettingsButtonItem : UIBarButtonItem

- (id)initWithTarget:(id)target action:(SEL)action;

@end
